var theElectorate;

window.onload = function main() {
    theElectorate = Controller.setup()

    //----------------- Prints the candidate votes without formating into columns--------//
    var candidateVoteList = document.createElement('div')
    candidateVoteList.setAttribute("id", "candidateVoteList")
    document.getElementById("content").appendChild(candidateVoteList)
    candidateVoteList.innerHTML = theElectorate.toCandidateResults()

    //----------------- Prints the candidate votes in table column format-------//
    var candidateVoteTable = document.createElement('div')
    candidateVoteTable.setAttribute("id", "candidateVoteTable")
    document.getElementById("content").appendChild(candidateVoteTable)
    candidateVoteTable.innerHTML = theElectorate.toCandidateResultsTable()

    //----------------- Prints the form format for inputing candidate votes------//
    var candidateForm= document.createElement('div')
    candidateForm.setAttribute("id", "candidateForm")
    document.getElementById("content").appendChild(candidateForm)
    candidateForm.innerHTML = theElectorate.toCandidateResultsForm()

    // var gridDiv = document.createElement('div')
    // gridDiv.className = "ui grid"
    // gridDiv.setAttribute("id", "gridHeading")
    // document.getElementById("content").appendChild(gridDiv)

    //---------------- Creates main Grid Div ------------------- //
    // var gridDiv = document.createElement('div')
    // gridDiv.className = "ui grid"
    // gridDiv.setAttribute("id", "gridContent")
    // document.getElementById("content").appendChild(gridDiv)
    //----------------------------------------------------------- //


    //----------------- 8 column div for the party ballot --------//
    // var partyDiv = document.createElement('div')
    // partyDiv.className = "eight wide column"
    // partyDiv.setAttribute("id", "partyGrid")
    // document.getElementById("gridContent").appendChild(partyDiv)

    // var partyBallot = document.createElement('div')
    // partyBallot.innerHTML = theElectorate.toPartyBallot()
    // partyDiv.appendChild(partyBallot)
    //-----------------------------------------------------------//

    //----------------- 8 column div for the candidate -----------//
    // var candidateDiv = document.createElement('div')
    // candidateDiv.className = "eight wide column"
    // candidateDiv.setAttribute("id", "candidateGrid")
    // document.getElementById("gridContent").appendChild(candidateDiv)

    // var candidateBallot = document.createElement('div')
    // candidateBallot.innerHTML = theElectorate.toCandidateBallot()
    // candidateDiv.appendChild(candidateBallot)
     
    //Comment the below two set of codes and uncomment the above  codes to print the data in radio option format only//
    // var candidateDiv = document.createElement('div')
    // candidateDiv.className = "sixteen wide column"
    // candidateDiv.setAttribute("id", "candidateGrid")
    // document.getElementById("gridContent").appendChild(candidateDiv)

    // var candidateBallot = document.createElement('div')
    // candidateBallot.innerHTML = theElectorate.toCandidateTable()
    // candidateDiv.appendChild(candidateBallot)
    
    // -----------------------------------------------------------//

 

    
}

