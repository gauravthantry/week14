class Controller {
	static setup() {
		var theElectorate
		theElectorate = new Electorate('Taranaki-King Country', 2017)
		
		//------------- Adding Parties -----------------//
		theElectorate.addParty("ACT New Zealand")
		theElectorate.addParty("Aotearoa Legalise Cannabis Party")
		theElectorate.addParty("Ban1080")
		theElectorate.addParty("Conservative")
		theElectorate.addParty("Democrats for Social Credit")
		theElectorate.addParty("Green Party")
		theElectorate.addParty("Internet Party")
		theElectorate.addParty("Labour Party")
		theElectorate.addParty("MANA")
		theElectorate.addParty("Māori Party")
		theElectorate.addParty("National Party")
		theElectorate.addParty("New Zealand First Party")
		theElectorate.addParty("New Zealand People's Party")
		theElectorate.addParty("NZ Outdoors Party")
		theElectorate.addParty("The Opportunities Party (TOP)")
		theElectorate.addParty("United Future")
		//-----------------------------------------------//

		//------------- Adding Candidates ----------------//
		theElectorate.addCandidate('HUMPHREY, Hilary Jane Hammonds','Labour Party')
		theElectorate.addCandidate('KURIGER, Barbara Joan','National Party')
		theElectorate.addCandidate('MOORE, Robert Bruce','Green Party')
		theElectorate.addCandidate('THOMSON, Allan George Robin','Conservative')
		//------------------------------------------------//

		theElectorate.setCandidateVotes('HUMPHREY, Hilary Jane Hammonds',8595)
		theElectorate.setCandidateVotes('KURIGER, Barbara Joan',23854)
		theElectorate.setCandidateVotes('MOORE, Robert Bruce',2900)
		theElectorate.setCandidateVotes('THOMSON, Allan George Robin',568)

		theElectorate.calcCandidatePercentages()

		theElectorate.toCandidateResults()
		return theElectorate
	}
}