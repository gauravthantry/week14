class Party {
  
    constructor(newName){
        this.name = newName
    }

    toString(){
      var party = `${this.name}`
      return party
    }

    toRadio(){
        var ballotRadio
        ballotRadio = `<div class="field">
                         <div class="ui radio checkbox">
                           <input type="radio"  name="party" tabindex="0">
                           <label style="color:aliceblue;">${this.name}</label>
                         </div>
                       </div>`
        return ballotRadio  
    }
}